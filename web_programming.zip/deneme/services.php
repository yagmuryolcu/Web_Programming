<?php
// Autoload and load Dotenv
require_once __DIR__ . '/vendor/autoload.php';

use Dotenv\Dotenv;
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load(); // Using load() for better practice

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Initialize variables
$scanError = '';
$scanResults = null;
$scannedUrl = '';
$statusClass = '';
$securityStatus = '';
$stats = [];

// Get API key from .env
$apiKey = $_ENV['VIRUSTOTAL_API_KEY'] ?? null;
$apiKeySet = !empty($apiKey); // Check if API key is set

// Check if URL is passed via GET
if (isset($_GET['url'])) {
    $url = $_GET['url'];
    $scannedUrl = filter_var($url, FILTER_SANITIZE_URL);

    if (filter_var($scannedUrl, FILTER_VALIDATE_URL)) {
        try {
            $scanResult = scanUrlWithVirusTotal($scannedUrl);

            if (isset($scanResult['data']['attributes']['stats'])) {
                $scanResults = $scanResult;
                $stats = $scanResult['data']['attributes']['stats'];

                if ($stats['malicious'] > 0) {
                    $securityStatus = 'Malicious';
                    $statusClass = 'danger';
                } elseif ($stats['suspicious'] > 0) {
                    $securityStatus = 'Suspicious';
                    $statusClass = 'warning';
                } else {
                    $securityStatus = 'Clean';
                    $statusClass = 'safe';
                }
            } else {
                $scanError = 'Unable to retrieve scan results. Please try again.';
            }
        } catch (Exception $e) {
            $scanError = $e->getMessage();
        }
    } else {
        $scanError = 'Invalid URL format.';
    }
} else {
    $scanError = 'No URL provided.';
}

function scanUrlWithVirusTotal($url) {
    $postData = ['url' => $url];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost/deneme/process_scan.php'); // Make sure to check the correct path
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        throw new Exception('cURL Error: ' . curl_error($ch));
    }

    curl_close($ch);
    return json_decode($response, true);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>URL Security Scanner - CyberAnalyze</title>
    <link rel="stylesheet" href="services.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">URL Security Scanner</div>
            <p class="description">Check the security of URLs using VirusTotal API.</p>
        </header>

        <div class="card glow-effect">
            <h2><i class="fas fa-shield-alt"></i> Scan URL</h2>
            <form method="GET" action="services.php">
                <div class="form-group">
                    <label for="url">Website URL</label>
                    <input type="url" id="url" name="url" placeholder="https://example.com" value="<?php echo htmlspecialchars($scannedUrl); ?>" required>
                </div>
                <button type="submit"><i class="fas fa-search"></i> Scan</button>

                <?php if (!$apiKeySet): ?>
                    <p class="api-key-note"><i class="fas fa-info-circle"></i> API key not found. Check the .env file.</p>
                <?php endif; ?>
            </form>
        </div>

        <?php if ($scanError): ?>
            <div class="error-message"><?php echo htmlspecialchars($scanError); ?></div>
        <?php endif; ?>

        <?php if ($scanResults && isset($scanResults['data']['attributes']['stats'])): ?>
            <div class="result-container">
                <div class="result-card">
                    <div class="result-header">
                        <h3>Results for <?php echo htmlspecialchars($scannedUrl); ?></h3>
                        <span class="result-status <?php echo $statusClass; ?>"><?php echo $securityStatus; ?></span>
                    </div>

                    <div class="result-details">
                        <div><strong>Last Scan:</strong> <?php echo date('d.m.Y H:i:s', $scanResults['data']['attributes']['last_analysis_date']); ?></div>
                    </div>

                    <div class="stats-container">
                        <div class="stat-card stat-malicious">
                            <div><?php echo $stats['malicious']; ?></div>
                            <div>Malicious</div>
                        </div>
                        <div class="stat-card stat-suspicious">
                            <div><?php echo $stats['suspicious']; ?></div>
                            <div>Suspicious</div>
                        </div>
                        <div class="stat-card stat-harmless">
                            <div><?php echo $stats['harmless']; ?></div>
                            <div>Harmless</div>
                        </div>
                        <div class="stat-card stat-undetected">
                            <div><?php echo $stats['undetected']; ?></div>
                            <div>Undetected</div>
                        </div>
                    </div>

                    <div class="vendors-container">
                        <h4>Security Providers</h4>
                        <div class="vendors-grid">
                            <?php 
                            foreach ($scanResults['data']['attributes']['last_analysis_results'] as $vendor => $result): 
                                $resultClass = in_array($result['category'], ['malicious', 'suspicious']) 
                                    ? 'result-malicious' : 'result-clean';
                                $resultText = match ($result['category']) {
                                    'malicious' => 'Malicious',
                                    'suspicious' => 'Suspicious',
                                    'undetected' => 'Undetected',
                                    'harmless', 'clean' => 'Clean',
                                    default => $result['category']
                                };
                            ?>
                                <div class="vendor-item">
                                    <div class="vendor-name"><?php echo htmlspecialchars($vendor); ?></div>
                                    <div class="vendor-result <?php echo $resultClass; ?>"><?php echo htmlspecialchars($resultText); ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> URL Security Scanner | Powered by VirusTotal API</p>
    </footer>
</body>
</html>
