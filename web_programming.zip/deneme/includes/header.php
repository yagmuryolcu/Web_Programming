<header>
    
        <div class="header-text">
            <h1>CyberAnalyze</h1>
            <p>Your Best Cyber Security Partner</p>
        </div>
        <form action="search.php" method="GET" class="search-form">
            <input type="text" name="query" placeholder="Search..." class="search-box">
            <button type="submit" class="search-button">🔍</button>
        </form>
  


<nav>
    <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="services.php">Services</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="education_videos.php">Education Videos</a></li>

    </ul>
</nav>
<div class="menu-toggle">
                <span></span>
                <span></span>
                <span></span>
            </div>


            </header>