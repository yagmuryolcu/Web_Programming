<?php

define('DBHOST', 'localhost');
define('DBNAME', 'searchbox');
define('DBUSER', 'root');
define('DBPASS', '');

// Veritabanı bağlantısını oluştur
$conn = new mysqli(DBHOST, DBUSER, DBPASS, DBNAME);

// Bağlantı hatası varsa
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
