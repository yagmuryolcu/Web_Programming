<footer>
    <p>&copy; 2025 CyberAnalyze. All rights reserved.</p>
</footer>
